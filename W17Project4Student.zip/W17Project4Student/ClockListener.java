package W17Project4StudentHelp;

public interface ClockListener {
	public void event(int tick);
}
